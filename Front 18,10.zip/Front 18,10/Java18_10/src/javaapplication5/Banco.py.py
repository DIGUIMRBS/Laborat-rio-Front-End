class Banco:
    def __init__(self, nome):
        self.nome = nome
        self.clientes = []

    def adicionar_cliente(self, cliente):
        self.clientes.append(cliente)

    def encontrar_cliente(self, nome_cliente):
        for cliente in self.clientes:
            if cliente.nome == nome_cliente:
                return cliente
        return None


class Cliente:
    def __init__(self, nome, idade, nome_banco):
        self.nome = nome
        self.idade = idade
        self.banco = Banco(nome_banco)
        self.conta = Conta()
    
    def realizar_deposito(self, valor):
        self.conta.depositar(valor)
    
    def realizar_saque(self, valor):
        if self.conta.saldo >= valor:
            self.conta.sacar(valor)
        else:
            print("Saldo insuficiente.")

    def verificar_saldo(self):
        return self.conta.saldo

    def realizar_pagamento(self, valor, metodo):
        if metodo == "credito":
            self.conta.debitar_credito(valor)
        elif metodo == "debito":
            self.conta.debitar_debito(valor)
        elif metodo == "pix":
            self.conta.debitar_pix(valor)
        else:
            print("Método de pagamento inválido.")

    def imprimir_extrato(self):
        self.conta.extrato()


class Conta:
    def __init__(self):
        self.saldo = 0
        self.extrato = []

    def depositar(self, valor):
        self.saldo += valor
        self.extrato.append(f"Depósito: +{valor}")

    def sacar(self, valor):
        self.saldo -= valor
        self.extrato.append(f"Saque: -{valor}")

    def debitar_credito(self, valor):
        self.saldo -= valor
        self.extrato.append(f"Pagamento Crédito: -{valor}")

    def debitar_debito(self, valor):
        self.saldo -= valor
        self.extrato.append(f"Pagamento Débito: -{valor}")

    def debitar_pix(self, valor):
        self.saldo -= valor
        self.extrato.append(f"Pagamento Pix: -{valor}")

    def extrato(self):
        print("Extrato da conta:")
        for movimento in self.extrato:
            print(movimento)


def main():
    print("Bem-vindo ao Sistema Bancário")
    nome_banco = input("Digite o nome do banco: ")
    nome_cliente = input("Digite o nome do cliente: ")
    idade_cliente = int(input("Digite a idade do cliente: "))

    banco = Banco(nome_banco)
    cliente = Cliente(nome_cliente, idade_cliente, nome_banco)
    banco.adicionar_cliente(cliente)

    while True:
        print("\nMenu:")
        print("1. Realizar depósito")
        print("2. Realizar saque")
        print("3. Verificar saldo")
        print("4. Realizar pagamento (crédito, débito, pix)")
        print("5. Imprimir extrato")
        print("6. Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            valor = float(input("Digite o valor do depósito: "))
            cliente.realizar_deposito(valor)
        elif opcao == "2":
            valor = float(input("Digite o valor do saque: "))
            cliente.realizar_saque(valor)
        elif opcao == "3":
            saldo = cliente.verificar_saldo()
            print(f"Saldo: {saldo}")
        elif opcao == "4":
            valor = float(input("Digite o valor do pagamento: "))
            metodo = input("Digite o método de pagamento (credito, debito, pix): ")
            cliente.realizar_pagamento(valor, metodo)
        elif opcao == "5":
            cliente.imprimir_extrato()
        elif opcao == "6":
            print("Saindo do sistema.")
            break
        else:
            print("Opção inválida. Tente novamente.")


if __name__ == "__main__":
    main()
